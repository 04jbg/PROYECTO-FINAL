<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
# Incluimos la clase conexion para poder heredar los metodos de ella.
require_once('conexion.php');


class Usuario extends Conexion
{

  public function login($user, $clave)
  {
    


    # Nos conectamos a la base de datos
    parent::conectar();


    // El metodo salvar sirve para escapar cualquier comillas doble o simple y otros caracteres que pueden vulnerar nuestra consulta SQL
    $user  = parent::salvar($user);
    $clave = parent::salvar($clave);

    // Si necesitas filtrar las mayusculas y los acentos habilita las lineas 36 y 37 recuerda que en la base de datos debe estar filtrado tambien para una validacion correcta
    /*$user  = parent::filtrar($user);
      $clave = parent::filtrar($clave);*/

    /*
        Para la validación del usuario podemos hacer dos cosas,
        validar que exista el email solamente y mostrar error en caso
        de que no, o validar ambos campos y mostrar un unico error,
        en este caso validare el usuario con ambos campos, si necesitas ayuda
        para hacer la filtracion 1 me puedes escribir o enviarme un email a codigoadsi@gmail.com
      */

    // traemos el id y el nombre de la tabla usuarios donde el usuario sea igual al usuario ingresado y ademas la clave sea igual a la ingresada para ese usuario.
    $consulta = 'select id, nombre, cargo from usuarios where email="' . $user . '" and clave= MD5("' . $clave . '")';
    /*
        Verificamos si el usuario existe, la funcion verificarRegistros
        retorna el número de filas afectadas, en otras palabras si el
        usuario existe retornara 1 de lo contrario retornara 0
      */

    $verificar_usuario = parent::verificarRegistros($consulta);

    // si la consulta es mayor a 0 el usuario existe
    if ($verificar_usuario > 0) {

      /* Bien ahora a jugar un poco :v */

      /*
           usa el metodo consultaArreglo ya que devuelve un arreglo de la primera fila encontrada
          es decir, como nosotros solo validamos a un usuario 
        */

      $user = parent::consultaArreglo($consulta);

      /*
           utilizamos $user[nombre_del_campo] Ok?
       
        */

      /*
          Inicializamos la sessión 
        */

      session_start();

      /*
          Las variables de sesion .
        */

      $_SESSION['id']     = $user['id'];
      $_SESSION['nombre'] = $user['nombre'];
      $_SESSION['cargo']  = $user['cargo'];

      /*
         solo puede ver un usuario con el cargo de
          administrador y no un usuario estandar, 
        */

      /*
          Recuerda:
          cargo con valor: 1 es: Administrador
          cargo con valor: 2 es: usuario estandar
        
        */

      // Verificamos que cargo tiene l usuario y asi mismo dar la respuesta a ajax para que redireccione
      if ($_SESSION['cargo'] == 1) {
        echo 'view/admin/index.php';
      } else if ($_SESSION['cargo'] == 2) {
        echo 'view/user/index.php';
      }


      // u.u finalizamos aqui :v

    } else {
      // El usuario y la clave son incorrectos
      echo 'error_3';
    }


    # Cerramos la conexion
    parent::cerrar();
  }

  public function registroUsuario($name, $email, $clave, $cargo)
  {
    parent::conectar();

    $name  = parent::filtrar($name);
    $email = parent::filtrar($email);
    $clave = parent::filtrar($clave);


    // validar que el correo no exito
    $verificarCorreo = parent::verificarRegistros('select id from usuarios where email="' . $email . '" ');


    if ($verificarCorreo > 0) {
      echo 'error_3';
    } else {

      parent::query('insert into usuarios(nombre, email, clave, cargo) values("' . $name . '", "' . $email . '", MD5("' . $clave . '"), "' . $cargo . '")');

      session_start();

      $_SESSION['nombre'] = $name;
      $_SESSION['cargo']  = $cargo;

      echo 'view/user/index.php';
    }

    parent::cerrar();
  }
  // recuperar contraseña
  public function recuperarContrasena($email)
  {
    parent::conectar();

    $email = parent::filtrar($email);


    // validar que el correo exista
    $verificarCorreo = parent::verificarRegistros('select id from usuarios where email="' . $email . '" ');


    if ($verificarCorreo > 0) {
      $mail = new PHPMailer;
      $mail->isSMTP();
      $mail->SMTPDebug = 2;
      $mail->Host = 'smtp.gmail.com';
      $mail->Port = 465;
      $mail->SMTPAuth = true;
      $mail->SMTPSecure = 'ssl';
      $mail->Username = 'camibal1995@gmail.com';
      $mail->Password = 'caanbavi';

      $mail->setFrom('camibal1995@gmail.com', 'administrador');
      $mail->addAddress($email);
      $mail->addReplyTo('camibal1995@gmail.com');

      $mail->isHTML(true);
      $mail->Subject = 'Enviado por ' . 'administrador';
      $mail->Body = '<h1 align=center>Da click: ' . 'http://localhost/loginPHP/confirmar-contrasena.php' . '<br>Email: ' . $email .'</h1>';
      if (!$mail->send()) {
        // $result = "Algo esta mal, por favor inténtelo de nuevo.";
        echo 'error.php';
      } else {
        header("Location: ../index.php");
        echo '../index.php';
      }
  
    } else {
      echo 'error.php';
    }

    parent::cerrar();
  }
  // cambiar contraseña
  public function cambiarContrasena($email, $clave)
  {
    parent::conectar();

    $email = parent::filtrar($email);
    $clave = parent::filtrar($clave);

    $claveEncript = md5($clave);
    // validar que el correo exista
    $verificarCorreo = parent::verificarRegistros('select id from usuarios where email="' . $email . '" ');


    if ($verificarCorreo > 0) {
      parent::query('update usuarios set email="' . $email . '",clave="' . $claveEncript . '" where email="' . $email . '"');
      echo 'index.php';
    } else {
      echo 'error.php';
    }

    parent::cerrar();
  }
  // actualizar perfil
  public function actualizarPerfil($name, $email, $claveActual, $clave)
  {
    parent::conectar();

    $name = parent::filtrar($name);
    $email = parent::filtrar($email);
    $claveActual = parent::filtrar($claveActual);
    $clave = parent::filtrar($clave);

    $claveEncript = md5($claveActual);
    // validar que el correo exista
    $verificarCorreo = parent::verificarRegistros('select id from usuarios where clave="' . $claveEncript . '" and  email="' . $email . '"');


    if ($verificarCorreo > 0) {
      parent::query('update usuarios set nombre="' . $name . '", email="' . $email . '",clave="' . $claveEncript . '" where email="' . $email . '"');
      echo './index.php';
    } else {
      echo 'error.php';
    }

    parent::cerrar();
  }
}