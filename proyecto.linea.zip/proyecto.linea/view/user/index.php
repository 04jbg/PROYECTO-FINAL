<?php
  session_start();

  // Validamos que exista una session y ademas que el cargo que exista sea igual a 1 (Administrador)
  if(!isset($_SESSION['cargo']) || $_SESSION['cargo'] != 2){
    header('location: ../../index.php');
  }

?>
<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
    <title>Login en PHP</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/bootstrap.min.css">
  </head>

  <body>
    <!-- ucfirst convierte la primera letra en mayusculas de una cadena -->
    <h1>
    Bienvenido Usuario  <?php echo ucfirst($_SESSION['nombre']); ?>
    </h1>
    <div  class="centrartexto">
    <a href="./actualizar-perfil.php">
      <button type="button"class="btn btn-primary btn-block" name="button">Actualizar perfil</button>
    </a>
    <a href="../../controller/cerrarSesion.php">
      <button type="button"class="btn btn-danger btn-block" name="button">Cerrar sesion</button>
    </a>
    </div>
  </body>
</html>
