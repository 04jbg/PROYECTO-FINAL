<?php
// Se prendio esta mrd :v
session_start();

// Validamos que exista una session y ademas que el cargo que exista sea igual a 1 (Administrador)
if (!isset($_SESSION['cargo']) || $_SESSION['cargo'] != 1) {
  /*
      Para redireccionar en php se utiliza header,
      pero al ser datos enviados por cabereza debe ejecutarse
      antes de mostrar cualquier informacion en el DOM es por eso que inserto este
      codigo antes de la estructura del html.
    */
  header('location: ../../index.php');
}

?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Login en PHP</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Estilos personalizados: archivo personalizado 100% real no feik -->
  <link rel="stylesheet" href="../../css/style.css">
  <link rel="stylesheet" href="../../css/bootstrap.min.css">
</head>

<body>
<H1>
  Bienvenido Administrador <?php echo ucfirst($_SESSION['nombre']); ?>
  </H1>
  <!-- ucfirst convierte la primera letra en mayusculas de una cadena -->
  <div class="centrartexto">
    <a href="./actualizar-perfil.php">
      <button type="button"class="btn btn-primary btn-block" name="button"> Actualizar perfil</button>
 </a>
     <a href="../../controller/cerrarSesion.php">
      <button type="button"class="btn btn-danger btn-block" name="button"> Cerrar sesion</button>
    </a>
  </div>
  
</body>

</html>